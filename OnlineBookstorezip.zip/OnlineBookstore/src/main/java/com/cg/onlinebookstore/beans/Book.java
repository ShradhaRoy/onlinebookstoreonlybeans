package com.cg.onlinebookstore.beans;

import java.util.Date;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import oracle.sql.BLOB;

@Entity
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="isbn_gen")
	@SequenceGenerator(name="isbn_gen",sequenceName = "isbn_seq",allocationSize = 1,initialValue = 920050083)
	private long ISBNno;
	BookCategory category;
	private String Title;
	private String Author;
	private String Description;
	private BLOB image;
	private float price;
	private Date date;
	@ManyToOne
	Customer customer;
	@OneToMany(mappedBy = "book",cascade=CascadeType.ALL)
	@MapKey
	private Map<Long, Review> review;
	
	

	public Book(BookCategory category, String title, String author, String description, BLOB image, float price,
			Date date, Customer customer, Map<Long, Review> review) {
		super();
		this.category = category;
		Title = title;
		Author = author;
		Description = description;
		this.image = image;
		this.price = price;
		this.date = date;
		this.customer = customer;
		this.review = review;
	}

	public Book() {
	}

	public long getISBNno() {
		return ISBNno;
	}

	public void setISBNno(long iSBNno) {
		ISBNno = iSBNno;
	}

	public BookCategory getCategory() {
		return category;
	}

	public void setCategory(BookCategory category) {
		this.category = category;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public BLOB getImage() {
		return image;
	}

	public void setImage(BLOB image) {
		this.image = image;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Author == null) ? 0 : Author.hashCode());
		result = prime * result + ((Description == null) ? 0 : Description.hashCode());
		result = prime * result + (int) (ISBNno ^ (ISBNno >>> 32));
		result = prime * result + ((Title == null) ? 0 : Title.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((image == null) ? 0 : image.hashCode());
		result = prime * result + Float.floatToIntBits(price);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (Author == null) {
			if (other.Author != null)
				return false;
		} else if (!Author.equals(other.Author))
			return false;
		if (Description == null) {
			if (other.Description != null)
				return false;
		} else if (!Description.equals(other.Description))
			return false;
		if (ISBNno != other.ISBNno)
			return false;
		if (Title == null) {
			if (other.Title != null)
				return false;
		} else if (!Title.equals(other.Title))
			return false;
		if (category != other.category)
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (image == null) {
			if (other.image != null)
				return false;
		} else if (!image.equals(other.image))
			return false;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		return true;
	}

	public Book(long iSBNno, BookCategory category, String title, String author, String description, BLOB image,
			float price, Date date, Customer customer) {
		super();
		ISBNno = iSBNno;
		this.category = category;
		Title = title;
		Author = author;
		Description = description;
		this.image = image;
		this.price = price;
		this.date = date;
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Book [ISBNno=" + ISBNno + ", category=" + category + ", Title=" + Title + ", Author=" + Author
				+ ", Description=" + Description + ", image=" + image + ", price=" + price + ", date=" + date
				+ ", customer=" + customer + "]";
	}
	

}