package com.cg.onlinebookstore.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.onlinebookstore.beans.Customer;

public interface RiviewDAO extends JpaRepository<Customer, Integer>{
}
