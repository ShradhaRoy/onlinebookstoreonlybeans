package com.cg.onlinebookstore.controllers;

public class BookstoreServicesControllers {

	public BookstoreServicesControllers() {
	}

}
