package com.cg.onlinebookstore.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.onlinebookstore.beans.Book;

public interface BookDAO extends JpaRepository<Book, Long> {
	

}
