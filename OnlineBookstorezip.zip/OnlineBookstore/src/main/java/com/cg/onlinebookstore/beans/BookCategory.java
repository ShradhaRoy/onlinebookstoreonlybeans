package com.cg.onlinebookstore.beans;

public enum BookCategory {
	THRILLER,HORROR,SCIFI,BIOGRAPHY,NONFICTION,ADVENTURE,COMIC,ROMCOM,POEMS,DOCUMENTARY
	

}
