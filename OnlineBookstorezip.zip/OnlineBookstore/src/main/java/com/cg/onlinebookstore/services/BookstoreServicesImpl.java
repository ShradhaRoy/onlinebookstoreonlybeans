package com.cg.onlinebookstore.services;

public class BookstoreServicesImpl {

	public BookstoreServicesImpl() {
	}

}
