package com.cg.onlinebookstore.beans;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String userID;
	private String email;
	private String Name;
	private String PhoneNo;
	@Embedded
	Address Address;
	private String Password;
	private boolean AdminRights;
	@OneToMany(mappedBy = "customer")
	@MapKey
	private Map<Long, Book> book= new HashMap<>();
	
	@OneToOne(cascade=CascadeType.ALL)
	Review review;
	public Customer() {
	}
	public Customer( String email, String name, String phoneNo,
			com.cg.onlinebookstore.beans.Address address, String password, boolean adminRights, Map<Long, Book> book,
			Review review) {
		super();
		this.email = email;
		Name = name;
		PhoneNo = phoneNo;
		Address = address;
		Password = password;
		AdminRights = adminRights;
		this.book = book;
		this.review = review;
	}
	public Customer(String userID, String email, String name, String phoneNo,
			com.cg.onlinebookstore.beans.Address address, String password, boolean adminRights, Map<Long, Book> book,
			Review review) {
		super();
		userID = userID;
		this.email = email;
		Name = name;
		PhoneNo = phoneNo;
		Address = address;
		Password = password;
		AdminRights = adminRights;
		this.book = book;
		this.review = review;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		userID = userID;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public Address getAddress() {
		return Address;
	}
	public void setAddress(Address address) {
		Address = address;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public boolean isAdminRights() {
		return AdminRights;
	}
	public void setAdminRights(boolean adminRights) {
		AdminRights = adminRights;
	}
	public Map<Long, Book> getBook() {
		return book;
	}
	public void setBook(Map<Long, Book> book) {
		this.book = book;
	}
	public Review getReview() {
		return review;
	}
	public void setReview(Review review) {
		this.review = review;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Address == null) ? 0 : Address.hashCode());
		result = prime * result + (AdminRights ? 1231 : 1237);
		result = prime * result + ((Name == null) ? 0 : Name.hashCode());
		result = prime * result + ((Password == null) ? 0 : Password.hashCode());
		result = prime * result + ((PhoneNo == null) ? 0 : PhoneNo.hashCode());
		result = prime * result + ((userID == null) ? 0 : userID.hashCode());
		result = prime * result + ((book == null) ? 0 : book.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((review == null) ? 0 : review.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (Address == null) {
			if (other.Address != null)
				return false;
		} else if (!Address.equals(other.Address))
			return false;
		if (AdminRights != other.AdminRights)
			return false;
		if (Name == null) {
			if (other.Name != null)
				return false;
		} else if (!Name.equals(other.Name))
			return false;
		if (Password == null) {
			if (other.Password != null)
				return false;
		} else if (!Password.equals(other.Password))
			return false;
		if (PhoneNo == null) {
			if (other.PhoneNo != null)
				return false;
		} else if (!PhoneNo.equals(other.PhoneNo))
			return false;
		if (
				userID == null) {
			if (other.userID != null)
				return false;
		} else if (!userID.equals(other.userID))
			return false;
		if (book == null) {
			if (other.book != null)
				return false;
		} else if (!book.equals(other.book))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (review == null) {
			if (other.review != null)
				return false;
		} else if (!review.equals(other.review))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Customer [UserID=" + userID + ", email=" + email + ", Name=" + Name
				+ ", PhoneNo=" + PhoneNo + ", Address=" + Address + ", Password=" + Password + ", AdminRights="
				+ AdminRights + ", book=" + book + ", review=" + review + "]";
	}
	
	

}
