package com.cg.onlinebookstore.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	private String City;
	private String ZipCode;
	private String Country;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String city, String zipCode, String country) {
		super();
		City = city;
		ZipCode = zipCode;
		Country = country;
	}
	
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getZipCode() {
		return ZipCode;
	}
	public void setZipCode(String zipCode) {
		ZipCode = zipCode;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((City == null) ? 0 : City.hashCode());
		result = prime * result + ((Country == null) ? 0 : Country.hashCode());
		result = prime * result + ((ZipCode == null) ? 0 : ZipCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (City == null) {
			if (other.City != null)
				return false;
		} else if (!City.equals(other.City))
			return false;
		if (Country == null) {
			if (other.Country != null)
				return false;
		} else if (!Country.equals(other.Country))
			return false;
		if (ZipCode == null) {
			if (other.ZipCode != null)
				return false;
		} else if (!ZipCode.equals(other.ZipCode))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Address [City=" + City + ", ZipCode=" + ZipCode + ", Country=" + Country + "]";
	}
	
	

}
