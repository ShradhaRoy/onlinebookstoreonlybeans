package com.cg.onlinebookstore.aspect;

public class BookstoreExceptionAspect {

	public BookstoreExceptionAspect() {
	}

}
