package com.cg.onlinebookstore.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.Size;

@Entity
public class Review {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int reviewId;
	private String comment;
	@Size(min=-1,max=5)
	
	private int rating;
	private String headline;
	@OneToOne(cascade = CascadeType.ALL)
	Customer customer;
	@ManyToOne
	Book book;
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((book == null) ? 0 : book.hashCode());
		result = prime * result + ((comment == null) ? 0 : comment.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((headline == null) ? 0 : headline.hashCode());
		result = prime * result + rating;
		result = prime * result + reviewId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Review other = (Review) obj;
		if (book == null) {
			if (other.book != null)
				return false;
		} else if (!book.equals(other.book))
			return false;
		if (comment == null) {
			if (other.comment != null)
				return false;
		} else if (!comment.equals(other.comment))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (headline == null) {
			if (other.headline != null)
				return false;
		} else if (!headline.equals(other.headline))
			return false;
		if (rating != other.rating)
			return false;
		if (reviewId != other.reviewId)
			return false;
		return true;
	}
	public Review(int reviewId, String comment, int rating, String headline, Customer customer, Book book) {
		super();
		this.reviewId = reviewId;
		this.comment = comment;
		this.rating = rating;
		this.headline = headline;
		this.customer = customer;
		this.book = book;
	}
	public Review(String comment, int rating, String headline, Customer customer, Book book) {
		super();
		this.comment = comment;
		this.rating = rating;
		this.headline = headline;
		this.customer = customer;
		this.book = book;
	}
	public Review() {
		super();
	}
	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", comment=" + comment + ", rating=" + rating + ", headline=" + headline
				+ ", customer=" + customer + ", book=" + book + "]";
	}
}
