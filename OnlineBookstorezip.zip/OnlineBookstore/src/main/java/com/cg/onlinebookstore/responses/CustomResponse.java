package com.cg.onlinebookstore.responses;

public class CustomResponse {

	public CustomResponse() {
		// TODO Auto-generated constructor stub
	}

}
