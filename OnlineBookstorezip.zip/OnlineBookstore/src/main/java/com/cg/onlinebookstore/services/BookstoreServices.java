package com.cg.onlinebookstore.services;

public class BookstoreServices {

	public BookstoreServices() {
	}

}
